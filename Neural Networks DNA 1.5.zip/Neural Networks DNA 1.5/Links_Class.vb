﻿Public Class Links_Class
    Public Weight As Decimal
End Class
