﻿Public Class Node_Class
    Public Links As New System.Collections.Generic.Dictionary(Of String, Links_Class)
    Public Value As Decimal
    Public TempValue As Decimal
    Public Type As Char
    Public Threshold As Decimal
End Class
