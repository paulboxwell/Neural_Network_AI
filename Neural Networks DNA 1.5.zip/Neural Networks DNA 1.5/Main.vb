﻿Public Class Main
    Public CreatureCount1 As Integer = 0
    Public Creatures1 As New System.Collections.Generic.Dictionary(Of String, Creature_Class)
    Public EnviroCount As Integer = 0
    Public Enviroments As New System.Collections.Generic.Dictionary(Of String, Form1)

    Dim address = "."
    Dim FileName = "Pool"

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim NewForm As New Form1
        NewForm.Show()
        EnviroCount += 1
        NewForm.EnviromentKey = EnviroCount
        Enviroments.Add(EnviroCount, NewForm)
    End Sub

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim x As SplashScreen1 = New SplashScreen1()
        x.ShowDialog()


        'Timer1.Enabled = True
        'Timer2.Enabled = True
        

        Label1.Text = address & "\" & FileName & ".txt"

        Dim current
        If System.IO.File.Exists(address & "\" & FileName & ".txt") = True Then
            FileOpen(1, address & "\" & FileName & ".txt", OpenMode.Input)
            Do While Not EOF(1)
                current = LineInput(1)
                Dim NewCreature As New Creature_Class
                NewCreature.SetNewFromDNA(current, 1)
                NewCreature.DNA = current
                CreatureCount1 += 1
                Creatures1.Add(CreatureCount1, NewCreature)
            Loop
            Me.Text = Creatures1.Count
            FileClose(1)
        Else
            Me.Text = "No Pool at default Directory ( " & address & "\" & FileName & ".txt )"
        End If
        Chart2.Series(0).Name = "Edgeless"
        Chart2.Series(1).Name = "Limited"
        'Chart1.Series.Add("Limited")



        Chart1.Series(0).Name = "Edgeless"
        Chart1.Series(1).Name = "Limited"

    End Sub
    Private Sub Main_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosing
        If Creatures1.Count > 0 Then
            Dim str_Creatures = Nothing
            Dim count = 0
            For Each Creature In Creatures1
                count += 1
                If count = Creatures1.Count Then
                    str_Creatures &= Creature.Value.DNA
                Else
                    str_Creatures &= Creature.Value.DNA & vbNewLine
                End If

            Next
            SaveFile(address, FileName, str_Creatures)
        End If
     
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Text = Creatures1.Count
    End Sub
    Sub SaveFile(ByVal address As String, ByVal Name As String, ByVal Input As String)
        FileOpen(1, address & "\" & Name & ".txt", OpenMode.Output)
        PrintLine(1, Input)
        FileClose(1)
    End Sub
    Function LoadFile(ByVal address As String, ByVal Name As String)
        LoadFile = Nothing
        If System.IO.File.Exists(address & "\" & Name & ".txt") = True Then
            FileOpen(1, address & "\" & Name & ".txt", OpenMode.Input)
            Do While Not EOF(1)
                LoadFile &= LineInput(1)
                If EOF(1) = True Then
                    Exit Do
                Else
                    LoadFile &= vbNewLine
                End If
            Loop

            FileClose(1)
        Else
            LoadFile = "ERROR"
        End If
    End Function

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Dim TotalCreatures As Integer = 0
        For Each Enviroment In Enviroments
            TotalCreatures += Enviroment.Value.Creatures.Count
        Next
        TotalCreatures += Creatures1.Count
        If Enviroments.Count <> 0 Then
            If TotalCreatures = 0 And CheckBox3.Checked Then
                For Each Enviro In Enviroments
                    'Enviro.Value.AddNew()
                    Enviro.Value.CheckBox7.Checked = True
                    Enviro.Value.Avarage_Gen_Public = 0
                    'Exit For
                Next
            Else
                For Each Enviro In Enviroments
                    Enviro.Value.CheckBox7.Checked = False
                    'Exit For
                Next
            End If
        End If
        Dim edgeless = 0
        Dim edgeless_count = 0
        Dim limited = 0
        Dim limited_count = 0

        Dim edgeless_Creature_Counter = 0
        Dim limited_Creature_Counter = 0

        For Each Enviroment In Enviroments
            RichTextBox1.Text &= Enviroment.Value.Avarage_Gen_Public & ","
            If Enviroment.Value.CheckBox5.Checked = True Then
                edgeless += Enviroment.Value.Avarage_Gen_Public
                edgeless_count += 1

                edgeless_Creature_Counter += Enviroment.Value.Creatures.Count()
            Else
                limited += Enviroment.Value.Avarage_Gen_Public
                limited_count += 1

                limited_Creature_Counter += Enviroment.Value.Creatures.Count()
            End If
        Next
        If CheckBox1.Checked = True Then
            Chart1.Series(0).Points.Add(Int(edgeless / edgeless_count))
            Chart1.Series(1).Points.Add(Int(limited / limited_count))

            Chart2.Series(0).Points.Add(Int(edgeless_Creature_Counter))
            Chart2.Series(1).Points.Add(Int(limited_Creature_Counter))
        End If
        RichTextBox2.Text &= Int(edgeless / edgeless_count) & ", " & Int(limited / limited_count)
        RichTextBox2.Text &= vbNewLine
        RichTextBox1.Text &= vbNewLine





    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Controls.Remove(Me.Controls.Item("graph"))

        If Timer2.Enabled = True Then
            Button2.Text = "Play all"
            Timer2.Enabled = False
            Timer1.Enabled = False
            For Each Enviroment In Enviroments
                Enviroment.Value.Timer1.Enabled = False
            Next
        Else
            Button2.Text = "Pause all"
            Timer2.Enabled = True
            Timer1.Enabled = True
            For Each Enviroment In Enviroments
                Enviroment.Value.Timer1.Enabled = True
            Next
        End If



    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        CheckBox1.Checked = True
        For X = 0 To 10 Step 1
            Dim NewForm As New Form1
            NewForm.RichTextBox1.Visible = False
            NewForm.CheckBox1.Checked = True
            NewForm.CheckBox6.Checked = True
            NewForm.CheckBox3.Checked = False
            NewForm.Size = New System.Drawing.Size(900, 900)
            NewForm.Show()
            EnviroCount += 1
            NewForm.EnviromentKey = EnviroCount
            Enviroments.Add(EnviroCount, NewForm)
        Next
        For X = 0 To 5 Step 1
            Dim NewForm As New Form1
            NewForm.RichTextBox1.Visible = False
            NewForm.CheckBox1.Checked = True
            NewForm.CheckBox5.Checked = True
            NewForm.CheckBox6.Checked = True
            NewForm.CheckBox3.Checked = False
            NewForm.Size = New System.Drawing.Size(900, 900)
            NewForm.Show()
            EnviroCount += 1
            NewForm.EnviromentKey = EnviroCount
            Enviroments.Add(EnviroCount, NewForm)
        Next
        Button2.Text = "Pause all"
        Timer2.Enabled = True
        Timer1.Enabled = True
        For Each Enviroment In Enviroments
            Enviroment.Value.Timer1.Enabled = True
        Next
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        For X = 0 To 5 Step 1
            Dim NewForm As New Form1
            NewForm.RichTextBox1.Visible = False
            NewForm.CheckBox1.Checked = True
            'NewForm.CheckBox5.Checked = True
            NewForm.CheckBox6.Checked = True
            NewForm.Size = New System.Drawing.Size(2000, 2000)
            NewForm.Show()
            EnviroCount += 1
            NewForm.EnviromentKey = EnviroCount
            Enviroments.Add(EnviroCount, NewForm)
        Next
        For X = 0 To 5 Step 1
            Dim NewForm As New Form1
            NewForm.RichTextBox1.Visible = False
            NewForm.CheckBox1.Checked = True
            'NewForm.CheckBox5.Checked = True
            NewForm.CheckBox6.Checked = True
            NewForm.CheckBox5.Checked = True
            NewForm.Size = New System.Drawing.Size(300, 300)
            NewForm.Show()
            EnviroCount += 1
            NewForm.EnviromentKey = EnviroCount
            Enviroments.Add(EnviroCount, NewForm)
        Next
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        For X = 0 To 4 Step 1
            Dim NewForm As New Form1
            NewForm.RichTextBox1.Visible = False
            NewForm.CheckBox1.Checked = True
            'NewForm.CheckBox5.Checked = True
            NewForm.CheckBox6.Checked = True
            NewForm.Size = New System.Drawing.Size(2000, 2000)
            NewForm.WindowState = 2
            NewForm.Show()
            EnviroCount += 1
            NewForm.EnviromentKey = EnviroCount
            Enviroments.Add(EnviroCount, NewForm)
        Next


    End Sub

   

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Creatures1 = New Dictionary(Of String, Creature_Class)
        FolderBrowserDialog1.ShowDialog()
        address = FolderBrowserDialog1.SelectedPath()
        Label1.Text = address & "\" & FileName & ".txt"

        Dim current
        If System.IO.File.Exists(address & "\" & FileName & ".txt") = True Then
            FileOpen(1, address & "\" & FileName & ".txt", OpenMode.Input)
            Do While Not EOF(1)
                current = LineInput(1)
                Dim NewCreature As New Creature_Class
                NewCreature.SetNewFromDNA(current, 1)
                NewCreature.DNA = current
                CreatureCount1 += 1
                Creatures1.Add(CreatureCount1, NewCreature)
            Loop
            Me.Text = Creatures1.Count
            FileClose(1)
        Else
            Me.Text = "No Pool at this directory"
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        For X = 0 To 5 Step 1
            Dim NewForm As New Form1
            NewForm.RichTextBox1.Visible = False
            NewForm.CheckBox1.Checked = True
            NewForm.CheckBox6.Checked = True
            NewForm.Size = New System.Drawing.Size(1200, 900)
            NewForm.Show()
            EnviroCount += 1
            NewForm.EnviromentKey = EnviroCount
            Enviroments.Add(EnviroCount, NewForm)
        Next
        For X = 0 To 5 Step 1
            Dim NewForm As New Form1
            NewForm.RichTextBox1.Visible = False
            NewForm.CheckBox1.Checked = True
            NewForm.CheckBox6.Checked = True
            NewForm.CheckBox5.Checked = True
            NewForm.Size = New System.Drawing.Size(900, 900)
            NewForm.Show()
            EnviroCount += 1
            NewForm.EnviromentKey = EnviroCount
            Enviroments.Add(EnviroCount, NewForm)
        Next
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Try
            Process.Start(address)
        Catch ex As Exception

        End Try

    End Sub
End Class