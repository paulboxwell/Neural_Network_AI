﻿Public Class Form1
    Public EnviromentKey = 0
    Dim CreatureCount As Integer = 0
    Public Creatures As New System.Collections.Generic.Dictionary(Of String, Creature_Class)
    Dim TargetX As Decimal = widthofarena / 2
    Dim TargetY As Decimal = heightofarena / 2
    Dim Pi = 3.14159265359
    Dim MaxSpeed = 100
    Dim Counterforautoadd As Integer
    Public Avarage_Gen_Public As Integer
    Dim LastGen As Integer = 0
    Public SelectedKey As String

    Dim widthofarena As Integer = 0
    Dim heightofarena As Integer = 0

    Function Addangle(ByVal P As Decimal, ByVal Q As Decimal)
        Dim Sum = P + Q
        Do
            If Sum < -Pi Then
                Sum += 2 * Pi
            Else
                If Sum > Pi Then
                    Sum -= 2 * Pi
                Else
                    Exit Do
                End If
            End If
        Loop
        Addangle = Sum
    End Function
    Sub AddNew()
        CreatureCount += 1
        Dim NewCreature As New Creature_Class
        NewCreature.SetNewCreature(10, 2)
        Randomize()
        For i = 0 To Rnd() * 15
            NewCreature.AddNode()
        Next
        NewCreature.X = Rnd() * (widthofarena - 60) + 30
        NewCreature.Y = Rnd() * (heightofarena - 80) + 50
        Creatures.Add(CreatureCount, NewCreature)
    End Sub

    Sub AddDNA(ByVal empty As Boolean)
        For Each Creature In Main.Creatures1
            'chance of placing creature
            Dim addnew As Boolean = False
            If empty = False Then
                If Rnd() * 10000 < 1 Then
                    addnew = True
                End If
            Else
                If Rnd() * 100 < 1 Then
                    addnew = True
                End If
            End If
            If addnew Then
                CreatureCount += 1
                Dim NewCreature As New Creature_Class

                NewCreature.SetNewFromDNA(Creature.Value.DNA, 1)

                Randomize()
                NewCreature.X = Rnd() * (widthofarena - 60) + 30
                Randomize()
                NewCreature.Y = Rnd() * (heightofarena - 80) + 50



                NewCreature.R = Int(Rnd() * 255)
                NewCreature.G = Int(Rnd() * 255)
                NewCreature.B = Int(Rnd() * 255)

                NewCreature.Health = 1000


                NewCreature.Colour = New SolidBrush(Color.FromArgb(NewCreature.R, NewCreature.B, NewCreature.G))
                'Add Clone of old
                Creatures.Add(CreatureCount, NewCreature)


                Main.Creatures1.Remove(Creature.Key)
                Exit For
            End If


        Next

    End Sub




    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        Counterforautoadd += 1
        If Counterforautoadd = 20 Then
            Counterforautoadd = 0
            If CheckBox2.Checked = True Then
                AddNew()
            End If
            If CheckBox6.Checked = True Then
                If Creatures.Count = 0 Then
                    AddDNA(True)
                Else
                    AddDNA(False)
                End If

            End If

        End If

        Dim point As Graphics
        Dim killed As Integer = 0
        Dim Count As Integer = 0
        Dim MakeNew As Boolean = False
        Dim DNAofNew As String = Nothing
        Dim GenofNew As Integer = 0
        Dim RofNew As Integer = 0
        Dim GofNew As Integer = 0
        Dim BofNew As Integer = 0
        Dim XofNew As Decimal = 0
        Dim YofNew As Decimal = 0



        Dim Highestgen = 0
        Dim Lowestgen = -1
        Dim GenSum = 0
        Dim EnergySum = 0

        point = Me.CreateGraphics

        If CheckBox3.Checked = True Then
            point.FillEllipse(Brushes.Red, TargetX - 10, TargetY - 10, 20, 20)
            point.DrawRectangle(Pens.Red, 20, 40, widthofarena - 60, heightofarena - 100)
        End If


        For Each Creature In Creatures
            'save to pool
            If CheckBox6.Checked = True Then
                If Rnd() * 10000 < 1 Then
                    If Creature.Value.Health > 100 Then
                        Creature.Value.Health -= 100
                        Creature.Value.PrintDNA()

                        Dim NewCreature As New Creature_Class
                        NewCreature.DNA = Creature.Value.DNA
                        Main.CreatureCount1 += 1
                        Main.Creatures1.Add(Main.CreatureCount1, NewCreature)
                    End If
                End If
            End If
            Creature.Value.OldX = Creature.Value.X
            Creature.Value.OldY = Creature.Value.Y
            Creature.Value.OldAngle = Creature.Value.Angle

            If Creature.Value.Generation > Highestgen Then
                Highestgen = Creature.Value.Generation
            End If
            If Lowestgen = -1 Then
                Lowestgen = Creature.Value.Generation
            End If
            If Creature.Value.Generation < Lowestgen Then
                Lowestgen = Creature.Value.Generation
            End If
            GenSum += Creature.Value.Generation
            EnergySum += Creature.Value.Health
            Count += 1

            'Inputs
            Dim DirecX = (Creature.Value.X - TargetX)
            Dim DirecY = (Creature.Value.Y - TargetY)
            Dim Angle = System.Math.Atan2(DirecY, DirecX)
            Dim Distance = (DirecX ^ 2 + DirecY ^ 2) ^ 0.5

            Creature.Value.Nodes(1).Value = Addangle(-Creature.Value.Angle, Angle)
            Creature.Value.Nodes(2).Value = Distance ^ 0.1
            'Extra inputs:
            Dim currentClosest = -1
            Dim NextClosest = -1
            DirecX = 1
            DirecY = 1
            Dim DirecX2 = 1
            Dim DirecY2 = 1
            ' Check for colitions between creatures!
            For Each Creature2 In Creatures
                If Creature2.Key <> Creature.Key Then
                    Dim dx = Creature.Value.X - Creature2.Value.X
                    Dim dy = Creature.Value.Y - Creature2.Value.Y
                    Dim dv = (dx ^ 2 + dy ^ 2) ^ 0.5

                    If dv < 20 And Creature.Value.Alive = True And Creature2.Value.Alive = True Then
                        Dim Damage = 1000
                        'my change for 1.6
                        If Creature.Value.Velocity ^ 2 < Creature2.Value.Velocity ^ 2 Then
                            If Creature.Value.Health > Damage Then
                                Creature.Value.Health -= Damage
                                Creature2.Value.Health += Damage
                            Else
                                Creature2.Value.Health += Creature.Value.Health
                                Creature.Value.Health = 0
                            End If
                        Else
                            If Creature2.Value.Health > Damage Then
                                Creature2.Value.Health -= Damage
                                Creature.Value.Health += Damage
                            Else
                                Creature.Value.Health += Creature2.Value.Health
                                Creature2.Value.Health = 0
                            End If
                        End If
                        'HERE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        'Dim temp = Creature.Value.Angle
                        'Creature.Value.Velocity *= 0.9
                        'Creature.Value.OldAngle = Creature2.Value.Angle
                        'Creature2.Value.Velocity *= 0.9
                        'Creature2.Value.OldAngle = temp
                        'Dim diff = Creature2.Value.OldAngle - Creature.Value.Angle
                        'If (diff ^ 2 < (Pi / 2) ^ 2) Then

                        'Creature.Value.Velocity = -Creature.Value.Velocity * 0.5
                        'Creature2.Value.Velocity = -Creature2.Value.Velocity * 0.5
                        'End If
                    End If

                    If currentClosest = -1 Or dv < currentClosest Then
                        NextClosest = currentClosest
                        currentClosest = dv
                        DirecX2 = DirecX
                        DirecY2 = DirecY
                        DirecX = dx
                        DirecY = dy
                    Else
                        If NextClosest = -1 Or dv < NextClosest Then
                            NextClosest = dv
                            DirecX2 = dx
                            DirecY2 = dy
                        End If
                    End If
                End If
            Next

            Angle = System.Math.Atan2(DirecY, DirecX)
            Distance = (DirecX ^ 2 + DirecY ^ 2) ^ 0.5
            Creature.Value.Nodes(3).Value = Addangle(-Creature.Value.Angle, Angle)
            Creature.Value.Nodes(4).Value = Distance ^ 0.1

            Angle = System.Math.Atan2(DirecY2, DirecX2)
            Distance = (DirecX2 ^ 2 + DirecY2 ^ 2) ^ 0.5
            Creature.Value.Nodes(5).Value = Addangle(-Creature.Value.Angle, Angle)
            Creature.Value.Nodes(6).Value = Distance ^ 0.1

            DirecX2 = Creature.Value.X - widthofarena / 2
            DirecY2 = Creature.Value.Y - heightofarena / 2
            Angle = System.Math.Atan2(DirecY2, DirecX2)
            Distance = (DirecX2 ^ 2 + DirecY2 ^ 2) ^ 0.5
            Creature.Value.Nodes(7).Value = Addangle(-Creature.Value.Angle, Angle)
            Creature.Value.Nodes(8).Value = Distance ^ 0.1

            Creature.Value.Nodes(9).Value = Creature.Value.Velocity
            Creature.Value.Nodes(10).Value = Creature.Value.Rateofchangeofangle




            Creature.Value.Run()

            Creature.Value.Rateofchangeofangle = Creature.Value.Nodes(11).Value + Creature.Value.Rateofchangeofangle

            Dim Max_turn = Pi / ((Creature.Value.Velocity ^ 2) ^ 0.5 + 10)
            If Creature.Value.Rateofchangeofangle > Max_turn Then
                Creature.Value.Rateofchangeofangle = Max_turn
            End If
            If Creature.Value.Rateofchangeofangle < -Max_turn Then
                Creature.Value.Rateofchangeofangle = -Max_turn
            End If

            Creature.Value.Angle = Addangle(Creature.Value.Angle, Creature.Value.Rateofchangeofangle)
            Creature.Value.Velocity += Creature.Value.Nodes(12).Value

            If Creature.Value.Velocity > MaxSpeed Then
                Creature.Value.Velocity = MaxSpeed
            End If
            If Creature.Value.Velocity < -MaxSpeed Then
                Creature.Value.Velocity = -MaxSpeed
            End If

            Creature.Value.X += System.Math.Cos(Creature.Value.Angle) * Creature.Value.Velocity
            Creature.Value.Y += System.Math.Sin(Creature.Value.Angle) * Creature.Value.Velocity

            If CheckBox5.Checked = True Then

            Else
                If Creature.Value.X > widthofarena - 40 Or Creature.Value.X < 20 Or Creature.Value.Y > heightofarena - 60 Or Creature.Value.Y < 40 Then
                    Creature.Value.Alive = False
                    killed += 1
                End If
            End If


            If Creature.Value.X < TargetX + 10 And Creature.Value.X > TargetX - 10 And Creature.Value.Y < TargetY + 10 And Creature.Value.Y > TargetY - 10 Then
                If CheckBox4.Checked = False Then
                    Creature.Value.Health += 6000
                End If

                If CheckBox3.Checked = True Then
                    point.FillEllipse(Brushes.Black, TargetX - 10, TargetY - 10, 20, 20)
                End If
                For vbdfhjs = 0 To 100 Step 1
                    TargetX = Rnd() * (widthofarena - 80) + 30
                    TargetY = Rnd() * (heightofarena - 130) + 50
                    Dim clear = True
                    For Each Creature3 In Creatures
                        If Creature3.Value.X < TargetX + 30 And Creature3.Value.X > TargetX - 30 And Creature3.Value.Y < TargetY + 30 And Creature3.Value.Y > TargetY - 30 Then
                            clear = False
                            Exit For
                        End If
                    Next
                    If clear = True Then
                        Exit For
                    End If
                Next
                'MakeNew = True
                'Creature.Value.PrintDNA()
                'DNAofNew = Creature.Value.DNA
                'GenofNew = Creature.Value.Generation
                'RofNew = Creature.Value.R
                'BofNew = Creature.Value.B
                'GofNew = Creature.Value.G
                'XofNew = Creature.Value.X
                'YofNew = Creature.Value.Y
            End If

            Creature.Value.Health -= (Creature.Value.Velocity ^ 2 ^ 0.5 + 0.1) * (Creature.Value.Rateofchangeofangle ^ 2 ^ 0.5 + 0.1)
            Creature.Value.Health -= Creature.Value.Nodes.Count / 500
            If Creature.Value.Health < 0 Then
                Creature.Value.Alive = False
                killed += 1
            End If

            If Creature.Value.Health > 2500 Then
                Creature.Value.Health -= 2500
                MakeNew = True
                Creature.Value.PrintDNA()
                DNAofNew = Creature.Value.DNA
                GenofNew = Creature.Value.Generation
                RofNew = Creature.Value.R
                BofNew = Creature.Value.B
                GofNew = Creature.Value.G
                XofNew = Creature.Value.X
                YofNew = Creature.Value.Y
            End If
        Next
        If MakeNew = True Then
            Dim NumberofChildren = 5
            Dim NumberofMutants = 1

            Dim EnergySplit = 2500 / (NumberofChildren + NumberofMutants + 1)


            For x = 0 To NumberofChildren - 1 Step 1
                'ADD CLONE
                CreatureCount += 1
                Dim NewCreature As New Creature_Class

                NewCreature.SetNewFromDNA(DNAofNew, 1)

                Randomize()
                NewCreature.X = XofNew + Rnd() * 50 - 25
                Randomize()
                NewCreature.Y = YofNew + Rnd() * 50 - 25

                NewCreature.R = RofNew
                NewCreature.G = GofNew
                NewCreature.B = BofNew

                NewCreature.Health = EnergySplit
                NewCreature.Generation = GenofNew

                NewCreature.Colour = New SolidBrush(Color.FromArgb(NewCreature.R, NewCreature.B, NewCreature.G))
                'Add Clone of old
                Creatures.Add(CreatureCount, NewCreature)
            Next
            If CheckBox1.Checked = True Then
                For X = 0 To NumberofMutants - 1 Step 1
                    'ADD MUTANT
                    Dim NewCreature As New Creature_Class
                    CreatureCount += 1
                    NewCreature = New Creature_Class
                    NewCreature.SetNewFromDNA(DNAofNew, 1)
                    NewCreature.Mutation()
                    Randomize()
                    NewCreature.X = XofNew + Rnd() * 50 - 25
                    Randomize()
                    NewCreature.Y = YofNew + Rnd() * 50 - 25
                    Randomize()
                    NewCreature.R = RofNew + Rnd() * 5 - 10
                    Randomize()
                    NewCreature.G = GofNew + Rnd() * 5 - 10
                    Randomize()
                    NewCreature.B = BofNew + Rnd() * 5 - 10

                    NewCreature.Health = EnergySplit
                    NewCreature.Generation = GenofNew + 1

                    If NewCreature.R > 255 Then
                        NewCreature.R -= 255
                    End If
                    If NewCreature.R < 0 Then
                        NewCreature.R += 255
                    End If

                    If NewCreature.G > 255 Then
                        NewCreature.G -= 255
                    End If
                    If NewCreature.G < 0 Then
                        NewCreature.G += 255
                    End If

                    If NewCreature.B > 255 Then
                        NewCreature.B -= 255
                    End If
                    If NewCreature.B < 0 Then
                        NewCreature.B += 255
                    End If

                    NewCreature.Colour = New SolidBrush(Color.FromArgb(NewCreature.R, NewCreature.B, NewCreature.G))

                    'Add mutant
                    Creatures.Add(CreatureCount, NewCreature)
                Next
            End If




        End If
        For i = 0 To killed
            For Each Creature In Creatures
                LastGen = Creature.Value.Generation
                If Creature.Value.Alive = False Then
                    If CheckBox3.Checked = True Then
                        Dim x1 As Integer = Int(Creature.Value.OldX)
                        Dim y1 As Integer = Int(Creature.Value.OldY)

                        Dim x2 As Integer = Int(Creature.Value.OldX + 30 * System.Math.Cos(Creature.Value.OldAngle))
                        Dim y2 As Integer = Int(Creature.Value.OldY + 30 * System.Math.Sin(Creature.Value.OldAngle))

                        Dim NewColour = New SolidBrush(Color.FromArgb(Int(Creature.Value.R * 0.1), Int(Creature.Value.B * 0.1), Int(Creature.Value.G * 0.1)))
                        Dim NewPen = New Pen(Color.FromArgb(Int(Creature.Value.R * 0.1), Int(Creature.Value.B * 0.1), Int(Creature.Value.G * 0.1)))
                        point.FillEllipse(NewColour, Creature.Value.OldX - 4, Creature.Value.OldY - 4, 8, 8)
                        point.DrawLine(NewPen, x1, y1, x2, y2)
                    End If

                    Creatures.Remove(Creature.Key)
                    Exit For
                End If
            Next
        Next
        If CheckBox3.Checked = True Then
            For Each Creature In Creatures
                Dim x1 As Integer = Int(Creature.Value.OldX)
                Dim y1 As Integer = Int(Creature.Value.OldY)

                Dim x2 As Integer = Int(Creature.Value.OldX + 30 * System.Math.Cos(Creature.Value.OldAngle))
                Dim y2 As Integer = Int(Creature.Value.OldY + 30 * System.Math.Sin(Creature.Value.OldAngle))

                Dim NewColour = New SolidBrush(Color.FromArgb(Int(Creature.Value.R * 0.1), Int(Creature.Value.B * 0.1), Int(Creature.Value.G * 0.1)))
                Dim NewPen = New Pen(Color.FromArgb(Int(Creature.Value.R * 0.1), Int(Creature.Value.B * 0.1), Int(Creature.Value.G * 0.1)))
                point.FillEllipse(NewColour, Creature.Value.OldX - 4, Creature.Value.OldY - 4, 8, 8)
                point.DrawLine(NewPen, x1, y1, x2, y2)


                x1 = Int(Creature.Value.X)
                y1 = Int(Creature.Value.Y)

                x2 = Int(Creature.Value.X + 30 * System.Math.Cos(Creature.Value.Angle))
                y2 = Int(Creature.Value.Y + 30 * System.Math.Sin(Creature.Value.Angle))
                NewPen = New Pen(Color.FromArgb(Int(Creature.Value.R), Int(Creature.Value.B), Int(Creature.Value.G)))
                point.FillEllipse(Creature.Value.Colour, Creature.Value.X - 4, Creature.Value.Y - 4, 8, 8)
                point.DrawLine(NewPen, x1, y1, x2, y2)
            Next
        End If
        If Count = 0 Then
            Avarage_Gen_Public = LastGen
        Else
            Avarage_Gen_Public = Int(GenSum / Count)
        End If

        Dim enviroType As String
        If CheckBox5.Checked Then
            enviroType = "Edgeless :"
        Else
            enviroType = "Limited  :"
        End If

        Me.Text = enviroType & " Count: " & CreatureCount & "   Number: " & Count & "   Highest Gen: " & Highestgen & "   Lowest Gen: " & Lowestgen & "   Sum Energy: " & Int(EnergySum / 10) * 10 & "   Avarage Gen: " & Avarage_Gen_Public


        If Creatures.Count = 0 And CheckBox7.Checked = True Then


            CreatureCount = 0
            AddNew()
            If True Then
                Dim Key = Nothing
                For Each Creature In Creatures
                    Key = Creature.Key
                Next
                DNAofNew = Creatures.Item(Key).DNA
                GenofNew = Creatures.Item(Key).Generation
                RofNew = Creatures.Item(Key).R
                BofNew = Creatures.Item(Key).B
                GofNew = Creatures.Item(Key).G
                XofNew = Creatures.Item(Key).X
                YofNew = Creatures.Item(Key).Y
                Creatures.Item(Key).PrintDNA()
                Dim DNA = Creatures.Item(Key).DNA
                For x = 0 To 8 Step 1
                    'ADD CLONE
                    CreatureCount += 1
                    Dim NewCreature As New Creature_Class

                    NewCreature.SetNewFromDNA(DNA, 1)

                    Randomize()
                    NewCreature.X = XofNew + Rnd() * 200 - 100
                    Randomize()
                    NewCreature.Y = YofNew + Rnd() * 200 - 100

                    NewCreature.R = RofNew
                    NewCreature.G = GofNew
                    NewCreature.B = BofNew

                    NewCreature.Generation = 0

                    NewCreature.Colour = New SolidBrush(Color.FromArgb(NewCreature.R, NewCreature.B, NewCreature.G))
                    'Add Clone of old
                    Creatures.Add(CreatureCount, NewCreature)
                Next
            End If


        End If
        If Rnd() * 10000 < 10 Then
            'random move
            If CheckBox3.Checked = True Then
                point.FillEllipse(Brushes.Black, TargetX - 10, TargetY - 10, 20, 20)
            End If

            For vbdfhjs = 0 To 100 Step 1
                TargetX = Rnd() * (widthofarena - 80) + 30
                TargetY = Rnd() * (heightofarena - 130) + 50




                Dim clear = True
                For Each Creature In Creatures
                    If Creature.Value.X < TargetX + 30 And Creature.Value.X > TargetX - 30 And Creature.Value.Y < TargetY + 30 And Creature.Value.Y > TargetY - 30 Then
                        clear = False
                        Exit For
                    End If
                Next
                If clear = True Then
                    Exit For
                End If
            Next


        End If

    End Sub

    Private Sub Form1_resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        Dim point As Graphics
        point = Me.CreateGraphics
        point.Clear(Color.Black)

        If Me.WindowState <> FormWindowState.Minimized Then
            widthofarena = Me.Width
            heightofarena = Me.Height
        End If


    End Sub




    Private Sub Form1_Closeing(sender As Object, e As EventArgs) Handles MyBase.FormClosing
        Main.Enviroments.Remove(EnviromentKey)
        'Main.RichTextBox1.Text = Main.Enviroments.Count
    End Sub

    Private Sub CheckBox9_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox9.CheckedChanged
        If CheckBox9.Checked = True Then
            Me.Size = SystemInformation.PrimaryMonitorSize
            Me.WindowState = 2
            Me.Location = New Point(0, 0)
            Me.TopMost = True
            Me.FormBorderStyle = 0
        Else
            Me.Size = New System.Drawing.Size(500, 500)
            Me.WindowState = 2
            Me.Location = New Point(20, 20)
            Me.TopMost = False
            Me.FormBorderStyle = 1
        End If
    End Sub

    Private Sub Form1_MouseClick(sender As Object, e As MouseEventArgs) Handles MyBase.MouseClick
        If RadioButton1.Checked = True Then
            Dim point As Graphics
            point = Me.CreateGraphics
            Point.FillEllipse(Brushes.Black, TargetX - 10, TargetY - 10, 20, 20)
            TargetX = MousePosition.X - Me.Location.X - 8
            TargetY = MousePosition.Y - Me.Location.Y - 30
        End If
        If RadioButton2.Checked = True Then
            Dim Closest = 300
            Dim ClosestIndex As String = ""
            Dim count = 0
            For Each Creature In Creatures

                Dim dx = Creature.Value.X - (MousePosition.X - Me.Location.X - 8)
                Dim dy = Creature.Value.Y - (MousePosition.Y - Me.Location.Y - 30)

                Dim distance = dx ^ 2 + dy ^ 2
                If distance < Closest Then
                    ClosestIndex = Creature.Key
                    Closest = distance
                End If
                count += 1
            Next
            If Closest < 300 Then
                Creatures(ClosestIndex).Alive = False
            End If
        End If
        If RadioButton3.Checked = True Then
            Dim Closest = 500
            Dim ClosestIndex As String = ""
            Dim count = 0
            For Each Creature In Creatures

                Dim dx = Creature.Value.X - (MousePosition.X - Me.Location.X - 8)
                Dim dy = Creature.Value.Y - (MousePosition.Y - Me.Location.Y - 30)

                Dim distance = dx ^ 2 + dy ^ 2
                If distance < Closest Then
                    ClosestIndex = Creature.Key
                    Closest = distance
                End If
                count += 1
            Next
            If Closest < 500 Then
                SelectedKey = ClosestIndex
                Dim x As Tracker = New Tracker()
                x.Load_Creature(Creatures(ClosestIndex))
                x.Show()
            End If
        End If

    End Sub
    Private Sub Form1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress
        If e.KeyChar = "p" Then
            If Timer1.Enabled = True Then
                Timer1.Enabled = False
            Else
                Timer1.Enabled = True
            End If
        End If
    End Sub

    Private Sub PlayPauseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PlayPauseToolStripMenuItem.Click
        If Timer1.Enabled = True Then
            Timer1.Enabled = False
        Else
            Timer1.Enabled = True
        End If
    End Sub

    Private Sub RandomToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RandomToolStripMenuItem.Click
        AddNew()
    End Sub

    Private Sub CopyAllDNAIntoClipboardToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyAllDNAIntoClipboardToolStripMenuItem.Click
        Dim DNAstring As String = Nothing
        For Each Creature In Creatures
            Creature.Value.PrintDNA()
            DNAstring &= vbNewLine & vbNewLine & vbNewLine & "<" & Creature.Value.DNA & ">"
        Next
        RichTextBox1.Text = DNAstring
    End Sub

    Private Sub FromDNAStringToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FromDNAStringToolStripMenuItem.Click
        Dim R = Int(Rnd() * 255)
        Dim G = Int(Rnd() * 255)
        Dim B = Int(Rnd() * 255)
        For C = 1 To Len(RichTextBox1.Text) Step 1
            CreatureCount += 1
            Dim NewCreature As New Creature_Class

            NewCreature.SetNewFromDNA(RichTextBox1.Text, C)

            NewCreature.X = widthofarena / 2 'Rnd() * (Me.Width - 200) + 100
            NewCreature.Y = heightofarena / 2 'Rnd() * (Me.Height - 200) + 100

            NewCreature.R = R
            NewCreature.G = G
            NewCreature.B = B

            NewCreature.Generation = 0

            NewCreature.Colour = New SolidBrush(Color.FromArgb(NewCreature.R, NewCreature.B, NewCreature.G))
            'Add Clone of old
            Creatures.Add(CreatureCount, NewCreature)
        Next
    End Sub

    Private Sub ShowHideTextboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowHideTextboxToolStripMenuItem.Click
        If RichTextBox1.Visible = True Then
            RichTextBox1.Visible = False
        Else
            RichTextBox1.Visible = True
        End If
        Dim point As Graphics
        point = Me.CreateGraphics
        point.Clear(Color.Black)
    End Sub

    Private Sub ShowEnviromentSettingsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowEnviromentSettingsToolStripMenuItem.Click
        If GroupBox2.Visible Then
            GroupBox2.Visible = False
        Else
            GroupBox2.Visible = True
        End If
        Dim point As Graphics
        point = Me.CreateGraphics
        point.Clear(Color.Black)
    End Sub

    Private Sub ShowInteractOptionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowInteractOptionsToolStripMenuItem.Click
        If GroupBox3.Visible Then
            GroupBox3.Visible = False
        Else
            GroupBox3.Visible = True
        End If
        Dim point As Graphics
        point = Me.CreateGraphics
        point.Clear(Color.Black)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        widthofarena = Me.Width
        heightofarena = Me.Height
    End Sub

    Private Sub ShowHideToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowHideToolStripMenuItem.Click
        If CheckBox3.Checked = True Then
            CheckBox3.Checked = False
            Dim point As Graphics
            point = Me.CreateGraphics
            point.Clear(Color.Black)
        Else
            CheckBox3.Checked = True
        End If

    End Sub
End Class
