﻿Public Class Tracker
    Dim Creature As Creature_Class

    Public Sub Load_Creature(ByVal Creature_pass)
        Creature = Creature_pass
    End Sub
    Private Sub Tracker_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Creature.PrintDNA()
        Label1.Text = "Health:  " + Creature.Health.ToString()
        Label2.Text = "Velocity: " + Creature.Velocity.ToString()
        Label3.Text = "Generation: " + Creature.Generation.ToString()
        Label4.Text = "Number of Nodes: " + Creature.Nodes.Count.ToString()
        Label5.Text = "R: " + Creature.R.ToString() + " G: " + Creature.G.ToString() + " B: " + Creature.B.ToString()
        RichTextBox1.Text = Creature.DNA
        Me.BackColor = Color.FromArgb(Int(Creature.R * 0.1), Int(Creature.B * 0.1), Int(Creature.G * 0.1))

    End Sub

End Class